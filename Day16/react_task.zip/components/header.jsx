function Header() {
    return (
       <header class="sticky top-0 z-[100] bg-[rgba(240,238,248,0.85)] backdrop-blur-md border-b border-[var(--border)] px-8 flex items-center justify-between h-16">

  
  <a class="logo flex items-center gap-2" href="#">
    <div class="logo-moon"></div>
    Sleep Diary
  </a>

  
  <nav class="hidden md:flex gap-4">
    <a href="#log" class="active" onclick="setNav(this)">Log</a>
    <a href="#history" onclick="setNav(this)">History</a>
    <a href="#insights" onclick="setNav(this)">Insights</a>
    <a href="#tips" onclick="setNav(this)">Tips</a>
  </nav>

  
  <button
    id="menu-btn"
    onclick="toggleMobileMenu()"
    class="md:hidden flex flex-col justify-center gap-[5px] w-9 h-9 p-2 rounded-lg border border-[var(--border-strong)] hover:bg-[var(--accent-soft)] transition-colors duration-200"
    aria-label="Toggle menu"
  >
    <span id="hline1" class="block w-full h-[1.5px] bg-[var(--ink)] transition-all duration-300"></span>
    <span id="hline2" class="block w-full h-[1.5px] bg-[var(--ink)] transition-all duration-300"></span>
    <span id="hline3" class="block w-full h-[1.5px] bg-[var(--ink)] transition-all duration-300"></span>
  </button>
</header>
    );
}

export default Header;